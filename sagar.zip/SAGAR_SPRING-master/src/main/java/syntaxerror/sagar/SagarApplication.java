package syntaxerror.sagar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SagarApplication {

	public static void main(String[] args) {
		SpringApplication.run(SagarApplication.class, args);
	}

}
